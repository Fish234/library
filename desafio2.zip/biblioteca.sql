CREATE DATABASE biblioteca;

CREATE TABLE libro(
	id SERIAL,
	titulo VARCHAR,
	autor VARCHAR,
	editorial VARCHAR,
	primary key(id)
);

CREATE TABLE lector(
	id SERIAL,
	nombre VARCHAR,
	fecha DATE,
	libro_id INT,
	PRIMARY KEY(id),
	FOREIGN KEY(libro_id) REFERENCES libro(id)
);